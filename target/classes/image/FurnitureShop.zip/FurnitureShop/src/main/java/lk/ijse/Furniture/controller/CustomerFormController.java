package lk.ijse.Furniture.controller;

import javafx.event.ActionEvent;
import lk.ijse.Furniture.util.Navigation;

import java.io.IOException;

public class CustomerFormController {

    public void employeeBtnOnAction(ActionEvent event) {

            try {
                Navigation.switchNavigation("EmployeePage_form.fxml",event);
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
}
