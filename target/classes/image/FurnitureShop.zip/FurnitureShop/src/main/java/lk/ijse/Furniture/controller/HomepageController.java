package lk.ijse.Furniture.controller;

import javafx.event.ActionEvent;
import lk.ijse.Furniture.util.Navigation;

import java.io.IOException;

public class HomepageController {
    public void customerBtnOnAction(ActionEvent event) {
        try {
            Navigation.switchNavigation("CustomerPage_form.fxml",event);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
