package lk.ijse.Furniture.controller;


import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import lk.ijse.Furniture.util.Navigation;

import java.io.IOException;

public class LoginFormController {




    @FXML
    private PasswordField passworld;

    @FXML
    private TextField username;

    @FXML
    private Label worngPassword;

    @FXML
    private AnchorPane root;


    @FXML
    private JFXButton loginButton;


    public void loginBtnOnAction(ActionEvent actionEvent) {
        try {
            Navigation.switchNavigation("HomePage_form.fxml",actionEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
