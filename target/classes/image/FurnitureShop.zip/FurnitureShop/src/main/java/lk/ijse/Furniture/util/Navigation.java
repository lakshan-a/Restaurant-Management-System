package lk.ijse.Furniture.util;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

public class Navigation {

    private static Stage stage;
    private static Scene scene;

    public static void switchNavigation(String link, ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Navigation.class.getResource("/view/"+link));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }

    public static void switchNavigation(String link, MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(Navigation.class.getResource("/view/"+link));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }
}
